package ca.sheridancollege.sinchang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidtermChanGaganjeetSinghApplicationTests {

	@Test
	void contextLoads() {
	}

}
