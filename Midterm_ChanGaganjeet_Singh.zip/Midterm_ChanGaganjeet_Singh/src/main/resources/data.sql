INSERT INTO books (book_name, price, quantity)
VALUES 
('Sundari', 45.50, 2),
('Harry Potter', 85.50, 8),
('Crime And Punishment', 15.50, 1),
('Janbaz Rakha', 35.50, 4),
('Panth Prakahs', 65.50, 9),
('Suraj Prakash', 25.50, 12),
('Elysium', 35.50, 4),
('Rich Dad Poor Dad', 65.75, 5),
('Beleo Nikalde Sher', 85.50, 1),
('Hanne Hanne Patshahi', 20.00, 4);