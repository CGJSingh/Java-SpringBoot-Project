CREATE TABLE 
books (id int not null primary key auto_increment, book_name VARCHAR(36), price DOUBLE, quantity INTEGER);