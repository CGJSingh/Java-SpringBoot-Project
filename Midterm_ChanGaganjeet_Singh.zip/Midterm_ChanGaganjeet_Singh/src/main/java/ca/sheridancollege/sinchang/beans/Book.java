package ca.sheridancollege.sinchang.beans;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Book {
	
	private int id;
	private String bookName;
	private double price;
	private int  quantity;
}
