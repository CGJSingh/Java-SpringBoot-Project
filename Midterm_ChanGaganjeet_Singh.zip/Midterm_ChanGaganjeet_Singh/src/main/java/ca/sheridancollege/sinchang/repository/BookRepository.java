package ca.sheridancollege.sinchang.repository;

import org.springframework.stereotype.Repository;

import ca.sheridancollege.sinchang.beans.Book;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor
public class BookRepository {
	
	private NamedParameterJdbcTemplate jdbc;
	
	public void addBook(Book book) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		
		String query = "INSERT INTO books (book_name, price, quantity) VALUES  (:na, :p, :q)";
		
		params.addValue("na", book.getBookName());
		params.addValue("p", book.getPrice());
		params.addValue("q", book.getQuantity());
		
		jdbc.update(query, params);
	}
	
	public ArrayList<Book> getBooks() {
		MapSqlParameterSource params = new MapSqlParameterSource();
		String query = "SELECT * FROM BOOKS";
		
		ArrayList<Book> books = (ArrayList<Book>)jdbc.query(query, params, new BeanPropertyRowMapper<Book>(Book.class));
		
		
		return books;
	}
	
	public void deleteBook(int id) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		String query = "DELETE FROM BOOKS WHERE id=:auto";
		
		params.addValue("auto", id);
		
		jdbc.update(query, params);
	}
	
	public void purchaseBook(int id) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		String query = "UPDATE BOOKS SET Quantity = Quantity - 1 WHERE id = :auto AND Quantity > 0";
		
		params.addValue("auto", id);
		
		jdbc.update(query, params);
	}
	
}
