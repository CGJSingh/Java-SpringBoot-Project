package ca.sheridancollege.sinchang.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.sinchang.beans.Book;
import ca.sheridancollege.sinchang.repository.BookRepository;
import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class BookController {
	
	BookRepository bookRepo;
	
	@GetMapping("/")
	public String root() {
		
		return "home.html";
	}
	
	@GetMapping("/add")
	public String add(Model model) {
		
		model.addAttribute("book", new Book());
		
		return "add.html";
	}
	
	@GetMapping("/view")
	public String view(Model model) {
		model.addAttribute("bookList", bookRepo.getBooks());
		return "view.html";
	}
	
	@PostMapping("/add")
	public String addSub(Model model, @ModelAttribute Book book) {
		
		bookRepo.addBook(book);
		
		return "redirect:/add";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteBook(@PathVariable int id, Model model) {
		bookRepo.deleteBook(id);
		return "redirect:/view";
	}
	
	@GetMapping("/purchase/{id}")
	public String purchaseBook(@PathVariable int id, Model model) {
		bookRepo.purchaseBook(id);
		return "redirect:/view";
	}
	
}
